import { Component, OnInit } from '@angular/core';
import {NavParams, ModalController} from '@ionic/angular';
import {AuthService} from '../auth-service.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.page.html',
  styleUrls: ['./modal.page.scss'],
})
export class ModalPage implements OnInit {

  passedValue = null;
  userDetails : any;
  responseData : any;
  dataSet : any;
  userPostData = {"project_name": ""};

  constructor(public router: Router,
    public navparams: NavParams,
    public authservice:AuthService,
    public modalcontroller: ModalController) {

  }

  //Getting the passed value of project name (from openmodal() in /tab2.ts page)
  ngOnInit() {
    this.passedValue = this.navparams.get('project_name');
    this.getDetails();
  }

  //Get the task information of the purticular project

  getDetails(){
    this.userPostData.project_name = this.passedValue;
    this.authservice.postData(this.userPostData, 'getDetails')
      .then((result) => {
        this.responseData = result;
        if (this.responseData.feedData) {
          this.dataSet = this.responseData.feedData;
          console.log(this.dataSet);
        } else {
          console.log("You no tasks yet.");
        }
      }, (err) => { console.log("Error in getdetails method");

      });
  }

  //Close button function for modal

  closeModal(){
    this.modalcontroller.dismiss();
  }
}
