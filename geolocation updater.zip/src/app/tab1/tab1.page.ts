import { Component } from '@angular/core';
import {Router} from '@angular/router';
import {AuthService} from '../auth-service.service';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  userDetails : any;
  locationData = {"latitude":null,"longitude":null,"username":""};
  data = null;
  responseData : any;

  constructor(
    private geolocation: Geolocation,
    public authservice: AuthService,
    public router: Router,
    public toastcontroller:ToastController
  ) {
      if(localStorage.getItem('userData')){
      const data = JSON.parse(localStorage.getItem('userData'));
      this.userDetails = data.userData;
  }
}
  //Logout Function

  logout(){
    localStorage.clear();
    setTimeout(() => this.navigateTosignin(), 1000);
  }

  //Navigates to signin page

  navigateTosignin(){
    this.router.navigateByUrl('/signin');
  }

  //Updates current user location in DB.

  updateLocation(){
    this.geolocation.getCurrentPosition().then((resp) => {
      this.locationData.latitude = resp.coords.latitude;
      this.locationData.longitude = resp.coords.longitude;
      this.locationData.username = this.userDetails.username;
      console.log(this.locationData.latitude);
      console.log(this.locationData.longitude);

      this.authservice.postData(this.locationData, 'updateLocation')
        .then((result) => {
          this.responseData = result;
          if (this.responseData.success) {
            console.log(this.responseData);
          } else {
            console.log("You have no tasks yet.");
          }
        }, (err) => { console.log("Error in getFeed method");

        });

        this.gpsUpdateToast();


}).catch((error) => {
  console.log('Error getting location', error);
});
  }

  //Successful Location Update Toast

  async gpsUpdateToast() {
    const toast = await this.toastcontroller.create({
      message: 'Your current location is updated.',
      duration: 3000
    });
    toast.present();
  }


}
