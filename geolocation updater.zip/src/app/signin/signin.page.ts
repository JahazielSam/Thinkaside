import { Component, OnInit, ViewChild} from '@angular/core';
//import { Component } from '@angular/core';
import { Http} from '@angular/http';
import {MenuController, AlertController, NavController,ToastController} from '@ionic/angular';
import { Router } from '@angular/router';
import {Headers, RequestOptions}  from '@angular/http';
import { LoadingController } from '@ionic/angular';
import {HttpClient} from '@angular/common/http';
import {AuthService} from '../auth-service.service';


@Component({
  selector: 'app-signin',
  templateUrl: './signin.page.html',
  styleUrls: ['./signin.page.scss'],
})
export class SigninPage implements OnInit {
  responseData : any;
  userData = {"username": "","password": ""};
  userDetails : any;

  //Check localStorage for loggedin user info.

  constructor(
    public router: Router,
    public toastcontroller:ToastController,
    public authservice: AuthService) {
      if(localStorage.getItem('userData')){
        const data = JSON.parse(localStorage.getItem('userData'));
        this.userDetails = data.userData;
        this.router.navigateByUrl('/tabs');
      }
  }

  ngOnInit() {
  }

  //Signin Funtion

  signin(){
  this.authservice.postData(this.userData,'login').then((result) => {
  this.responseData = result;
  if(this.responseData.userData){
  console.log(this.responseData);
  localStorage.setItem('userData', JSON.stringify(this.responseData));
  console.log("Stored locally");
  this.router.navigateByUrl('/tabs');
  }
  else{
    this.loginErrorToast();
    console.log("Wrong username or password"); }
}, (err) => {
  console.log("signin function error");
});
}

//Login error toast

async loginErrorToast() {
  const toast = await this.toastcontroller.create({
    message:'Wrong Username or Password',
    position: 'bottom',
    duration: 3000
  });
  toast.present();
}

}
