import { Component } from '@angular/core';
import {Router} from '@angular/router';
import {AuthService} from '../auth-service.service';
import {ModalController} from '@ionic/angular';
import {ModalPage} from '../modal/modal.page';
import { ToastController } from '@ionic/angular';


@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})

export class Tab2Page {
    updateProName = null;
    userDetails : any;
    responseData : any;
    dataSet : any;
    userPostData = {"userid": ""};
    updateData = {"project_name":""}
    ngOnInit() {
      this.startTimer();
  }

  constructor(
    public router: Router,
    public authservice: AuthService,
    public modalcontroller: ModalController,
    public toastcontroller: ToastController
  ) {
    //checks for localdata

    if(localStorage.getItem('userData')){
      const data = JSON.parse(localStorage.getItem('userData'));
      this.userDetails = data.userData;
      this.userPostData.userid = this.userDetails.username;

      //function call for incomplete task.
      this.getuserFeed();
      console.log("Constructor invoked");
    }else{
      console.log("No local data available");
    }
    //ToastCall for swipe info.
    this.showSwipeInfoToast();
  }

  //Logout Function (clearing local storage and navigation)

  logout(){
    localStorage.clear();
    setTimeout(() => this.navigateTosignin(), 1000);
  }

  //Navigation function to authentication page

  navigateTosignin(){
    this.router.navigateByUrl('/signin');
  }

  //Check for local storage information and gets the uncompleted tasks of the user

  getuserFeed() {
    if(localStorage.getItem('userData')){
      const data = JSON.parse(localStorage.getItem('userData'));
      this.userDetails = data.userData;
      this.userPostData.userid = this.userDetails.username;
      console.log("getfeedfunc invoked");
    }else{
      console.log("No local data available");
    }
    console.log(this.userPostData.userid);
    this.authservice.postData(this.userPostData, 'getFeed')
      .then((result) => {
        this.responseData = result;
        if (this.responseData.feedData) {
          this.dataSet = this.responseData.feedData;
          console.log(this.dataSet);
        } else {
          console.log("You have no tasks yet.");
        }
      }, (err) => { console.log("Error in getFeed method");

      });
  }

  //Pull to refresh body properties and timer function calls

  doRefresh(event) {
    console.log('Begin async operation');
    this.getuserFeed();
    setTimeout(() => {
      console.log('Async operation has ended');
      event.target.complete();
    }, 2000);
  }

  //Timer for auto-refresh of the tasks list

  startTimer(){
    setInterval(()=>{
      this.getuserFeed();
    },5000);
  }

//Updating completion information

  check(item){
    this.dataSet = this.dataSet.filter(i => i.project_name != item.project_name);
    this.updateData.project_name = item.project_name;
    console.log(this.updateData.project_name);
    this.authservice.postData(this.updateData, 'updateCompletion')
      .then((result) => {
        this.responseData = result;
        if (this.responseData.success) {
          console.log(this.dataSet);
        } else {
          console.log("API error");
        }
      }, (err) => { console.log("Error in completion uptate");

      });

      //Successful task completion toast.
      this.taskCompletedToast(item);

  }

  //Task details modal call function

  triggermodal(item){
    this.updateProName = item.project_name;
    this.openModal();
  }

//Modal generation and its properties

  async openModal(){
    const modal = await this.modalcontroller.create({
      component: ModalPage,
      componentProps:{
        project_name:this.updateProName
      }
    });
    modal.present();
  }

  //Swipe info. toast for the tasks.

  async showSwipeInfoToast() {
    const toast = await this.toastcontroller.create({
      message: 'Swipe the tasks left to update our completion',
      position: 'top',
      buttons: [
         {
          text: 'Close',
          role: 'cancel',
          side: 'end',
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });

    toast.present();
  }

  //Successful task complete toast def.

  async taskCompletedToast(item) {
    const toast = await this.toastcontroller.create({
      message: item.project_name + ' is marked as completed',
      duration: 3000
    });
    toast.present();
  }


}
